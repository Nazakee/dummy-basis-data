INSERT INTO kelas_tiket ("id_kelas", "golongan", "harga_tiket") VALUES
('KLS0001', 'Early Bird', 150000),
('KLS0002', 'Regular', 250000),
('KLS0003', 'Festival', 400000),
('KLS0004', 'Tribune', 350000),
('KLS0005', 'VIP', 800000),
('KLS0006', 'VVIP', 1200000),
('KLS0007', 'Platinum', 2000000),
('KLS0008', 'Gold', 1000000),
('KLS0009', 'Silver', 600000),
('KLS0010', 'Standing Area', 300000),
('KLS0011', 'Backstage Pass', 2500000),
('KLS0012', 'Meet & Greet', 1800000);
